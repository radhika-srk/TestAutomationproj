package com.project.Durgasoft8AMBatch.POM;

public class AudiCar extends Car
{
	public void openGPS()
	{
		
	}
}
