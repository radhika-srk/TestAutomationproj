package com.project.Durgasoft8AMBatch.POM;

public class Engine 
{
	
	String eName;
	
	public void startUp()
	{
		System.out.println("Engine starting...");
	}
}
